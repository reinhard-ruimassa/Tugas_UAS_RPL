<!-- search form -->
                    <!--<form action="#" method="get" class="sidebar-form">
                        <div class="input-group">
                            <input type="text" name="q" class="form-control" placeholder="Cari Sesuatu.?"/>
                            <span class="input-group-btn">
                                <button type='submit' name='search' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
                            </span>
                        </div>
                    </form>-->
                    <!-- /.search form -->
                    <!-- sidebar menu: : style can be found in sidebar.less --><br />
                    <ul class="sidebar-menu">
                        <li class="active">
                            <a href="index1.php">
                                <i class="glyphicon glyphicon-dashboard"></i> <span>Dashboard</span>
                            </a>
                        </li>
                        <li class="active">
                            <a href="index.php">
                                <i class="glyphicon glyphicon-file"></i> <span>Belanja Lagi</span>
                            </a>
                        </li>
                    </ul>
                    