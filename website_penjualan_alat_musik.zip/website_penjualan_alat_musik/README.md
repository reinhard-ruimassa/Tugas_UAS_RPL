# WarNasOL (Aplikasi Penjualan Makanan Online) Dengan PHP, MySQL dan Bootstrap 3

Aplikasi ini merupakan pengembangan dari aplikasi sebelumnya yaitu Aplikasi Toko Online DistroIT
yang di bangun dengan menggunakan PHP native database MySQL dan Bootstrap 3, untuk aplikasi lainnya 
dan tutorial lainnya bisa menuju link berikut ini www.hakkoblogs.com

Halaman Index
![gambar-index](https://user-images.githubusercontent.com/5027795/53283086-a88b9f00-3773-11e9-833a-2fa684a6bec9.png)

Halaman Customer
![gabar-cus](https://user-images.githubusercontent.com/5027795/53283125-146e0780-3774-11e9-9eec-7381388d600c.png)

Dashboard Admin
![gambar-admin](https://user-images.githubusercontent.com/5027795/53283126-15069e00-3774-11e9-88e2-3a0ac56d5e2b.png)

Halaman Keranjang Belanja
![gambar-cart](https://user-images.githubusercontent.com/5027795/53283127-15069e00-3774-11e9-9ecd-c903fa47232e.png)

Dashboard Customer
![gambar-customer](https://user-images.githubusercontent.com/5027795/53283128-15069e00-3774-11e9-99fd-6cf69545d06b.png)

Halaman Menu
![gambar-enu](https://user-images.githubusercontent.com/5027795/53283129-159f3480-3774-11e9-95b3-533c1d05d00b.png)

Untuk aplikasi lainnya silahkan ke www.hakkoblogs.com


